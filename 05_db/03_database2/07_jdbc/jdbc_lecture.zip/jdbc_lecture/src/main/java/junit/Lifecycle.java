package junit;

public class Lifecycle {
}
