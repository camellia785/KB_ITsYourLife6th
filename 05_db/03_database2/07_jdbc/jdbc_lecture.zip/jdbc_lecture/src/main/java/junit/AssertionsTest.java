package junit;

public class AssertionsTest {

}
